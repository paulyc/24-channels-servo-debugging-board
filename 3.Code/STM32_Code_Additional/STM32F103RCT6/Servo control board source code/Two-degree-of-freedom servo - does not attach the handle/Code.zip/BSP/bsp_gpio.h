/**
* @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
* @file         bsp_gpio.h
* @author       
* @version      V1.0
* @date         
* @brief        gpioͷ�ļ�
* @details      
* @par History  ������˵��
*                 
* version:	
*/

#ifndef __BSP_GPIO_H__
#define __BSP_GPIO_H__	

void Servo_GPIO_Init(void);




#endif

